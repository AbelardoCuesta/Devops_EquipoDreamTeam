import uuid

def uuid4Str():
    test = str(uuid.uuid4())
    return test
    
