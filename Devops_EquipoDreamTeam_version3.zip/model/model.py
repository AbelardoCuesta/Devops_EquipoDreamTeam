from .base import Base
from .lista_negra import Lista_negra
